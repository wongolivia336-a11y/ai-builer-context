# 图像识别 AR 与设备桥接

## Demo Day 识别图

漫游页内的“查看 / 单独下载 8 张识别图”可下载每个目标的独立 SVG。原始画布为 600 × 600，黑色识别底板带不对称白色块面，保持统一的高反差视觉；请完整保留外侧白色留白和黑色边框。

| 目标索引 | 文件 | 唯一泡泡 |
| --- | --- | --- |
| 0 | `memo-01-river-wind.svg` | 河面上的风 |
| 1 | `memo-02-alley-bell.svg` | 巷口的钟声 |
| 2 | `memo-03-passing-steps.svg` | 刚经过的人 |
| 3 | `memo-04-osmanthus-tea.svg` | 桂花茶的下午 |
| 4 | `memo-05-after-rain.svg` | 雨停以后 |
| 5 | `memo-06-market-light.svg` | 收摊前的灯 |
| 6 | `memo-07-goodnight.svg` | 没说出口的晚安 |
| 7 | `memo-08-bicycle-bell.svg` | 车铃经过 |

打印建议：方形原尺寸至少 65 mm；使用哑光纸，避免反光、褶皱、裁切边框或把多个目标拼进一张图。每张目标单独举起，在漫游页缓慢移动到镜头前。MindAR 通过图像纹理特征跟踪目标，不把一张图片里的多个特征点当成多个泡泡；输入顺序就是目标索引，代码映射表保持同序。实际场地仍要以 Android 摄像头测试识别距离、照明和印刷质量。

## 扫描与渲染流程

1. 用户点击“扫描识别图”后才申请后置相机和传感器权限；相机需要 HTTPS/localhost。
2. 第一次扫描从 `public/markers/` 载入 8 个 SVG，MindAR 编译图像特征，进度复用泡泡水胶囊；完成的目标数据缓存到 IndexedDB。后续扫描直接读取缓存。
3. MindAR 同时最多跟踪 1 张图，避免手机持续追踪 8 个目标造成负担。每个目标锚点挂载唯一 Three.js 泡泡，心形、星形、花形、云朵等形态使用有厚度的高光材质。
4. `devicemotion` / `deviceorientation` 可用时，将设备倾斜平滑映射成泡泡的纵向轻浮；浏览器未授权/不支持传感器时，仍有低幅度环境漂浮。
5. 发现目标后显示声音详情、试听和留言。捕捉只响应收到的设备信号或明确标注的“模拟实体按键”。播放结束后气泡沿右侧边缘缩小并消失。

## Wi-Fi 模块消息桥接

本演示提供一个可配置 WebSocket 输入适配器，不包含 ESP32 固件或实际硬件。手机和模块/桥接服务需在同一网络，硬件在实体按键按下时发送 JSON 消息：

```json
{ "type": "capture", "bubbleId": "wind" }
```

也可发送 0 到 7 的目标索引：

```json
{ "type": "capture", "targetIndex": 0, "rssi": -57 }
```

`bubbleId` 可用：`wind`、`bell`、`steps`、`osmanthus`、`rain`、`market`、`goodnight`、`bicycle`。若只发送 `type`，程序使用当前识别到的目标。状态消息中可包含数值 `rssi` 供界面显示。

配置方式：

- 部署/演示时添加查询参数 `?deviceWs=wss%3A%2F%2Fbridge.example%2Fevents`。
- 或在构建环境设置 `VITE_MEMO_CATCHER_WS`（旧变量 `VITE_ECHOCASTER_WS` 仍可用）。
- 默认没有 endpoint，界面显示演示模式，并提供可见的模拟按键。

浏览器网页不能读取任意附近 Wi-Fi 设备的 RSSI，也不会自动发现 ESP32。Wi-Fi 连接状态或实体按键需由模块/桥接服务主动发送到 WebSocket。HTTPS 页面应使用有效证书的 WSS；浏览器会阻止不安全页面通过 `ws://` 混合内容访问。固件协议、鉴权、断线恢复和硬件测试仍需与装置团队一起确认。

## 运行边界

当前通过 `index.html` 的 import map 从 CDN 延迟加载 MindAR 与匹配版本的 Three.js，因此页面首次加载或首次 AR 扫描需要网络。相机画面、图像特征识别和 WebGL 泡泡为浏览器真实运行能力；评论、音频合成、捕捉水流和右侧吸收动效为本机演示。这里的图像识别锚点只在镜头看见印刷目标时稳定存在，不能替代 GPS 地理锚点，也不会在离开目标后长期固定到真实世界坐标。
